package com.cg.anurag.dto;


	import javax.persistence.Entity;
	import javax.persistence.Id;

import java.time.LocalDate;

import javax.persistence.Column;
	@Entity
	public class Test
	{
	   @Id	
	   
	   @Column(name="test_id")
	   int testId;
	   @Column(name="test_date")
	   LocalDate testDate;
	   @Column(name="test_title")
	   String testTitle;
	   @Column(name="test_start_time")
	   String testStartTime;
	   @Column(name="test_end_time")
	   String testEndTime;
	   @Column(name="test_duration")
	   String testDuration;
	   @Column(name="test_total_marks")
	   double testTotalMarks;
	   public Test() {}
	public Test(LocalDate testDate, int testId, String testTitle, String testStartTime, String testEndTime,
			String testDuration, double testTotalMarks) {
		super();
		this.testDate = testDate;
		this.testId = testId;
		this.testTitle = testTitle;
		this.testStartTime = testStartTime;
		this.testEndTime = testEndTime;
		this.testDuration = testDuration;
		this.testTotalMarks = testTotalMarks;
	}
	public LocalDate getTestDate() {
		return testDate;
	}
	public void setTestDate(LocalDate testDate) {
		this.testDate = testDate;
	}
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public String getTestTitle() {
		return testTitle;
	}
	public void setTestTitle(String testTitle) {
		this.testTitle = testTitle;
	}
	public String getTestStartTime() {
		return testStartTime;
	}
	public void setTestStartTime(String testStartTime) {
		this.testStartTime = testStartTime;
	}
	public String getTestEndTime() {
		return testEndTime;
	}
	public void setTestEndTime(String testEndTime) {
		this.testEndTime = testEndTime;
	}
	public String getTestDuration() {
		return testDuration;
	}
	public void setTestDuration(String testDuration) {
		this.testDuration = testDuration;
	}
	public double getTestTotalMarks() {
		return testTotalMarks;
	}
	public void setTestTotalMarks(double testTotalMarks) {
		this.testTotalMarks = testTotalMarks;
	}
	}