package com.cg.anurag.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.anurag.dao.TestDAO;
import com.cg.anurag.dto.Test;

@Service
public class TestService 
{
    @Autowired
    TestDAO tdao;
    public void setTdao(TestDAO bdao) { this.tdao=tdao;}
    @Transactional(readOnly=true)
    public Optional<Test> getTestDetails(int testId)
    {
    	return tdao.findById(testId);
    }
    @Transactional
    public Test insertTest(Test test)
    {
        return tdao.save(test);
    }
    
    @Transactional(readOnly=true)
    public List<Test> getTests()
    {
    	return tdao.findAll();
    }
    @Transactional
    public String deleteTest(int testId)
    {
    	tdao.deleteById(testId);
    	return "Test Deleted";
    }
    
  /*  @Transactional
    public String updateTest(Test newTest)
    {
    	Test test = tdao.findById(newTest.getTestId()).get();
    	if(test!=null)
    	{
    	 test.setTestDate(newTest.getTestDate());
    	  test.setTestTitle(newTest.getTestTitle());
    	  test.setTestStartTime(newTest.getTestStartTime());
    	  test.setTestEndTime(newTest.getTestEndTime());
    	  test.setTestDuration(newTest.getTestDuration());
    	  test.setTestTotalMarks(newTest.getTestTotalMarks());
    	  return "Test Modified";
    	}
    	return "Update Failed";
    }*/
    
}
