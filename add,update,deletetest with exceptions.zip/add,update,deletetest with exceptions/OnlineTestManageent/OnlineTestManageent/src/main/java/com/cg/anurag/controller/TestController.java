package com.cg.anurag.controller;


	import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.dto.Test;
import com.cg.anurag.service.TestService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RestController 
	public class TestController
	{
		@Autowired
		TestService testService;
		public void setTestService(TestService testService)
		{
			this.testService=testService;
		}
		@GetMapping(value="/getTest/{testId}",produces="application/json")
	      public ResponseEntity<Optional<Test>> getTest(@PathVariable int testId)
	      {
	    	  Optional<Test> test =  testService.getTestDetails(testId);
	    	  if(test.isPresent())
	    		  return new ResponseEntity<Optional<Test>>(test,HttpStatus.OK);
	    	  return new ResponseEntity<Optional<Test>>(test,HttpStatus.NOT_FOUND);
	      }
	  
	  
	   @GetMapping(value="/getTests",produces="application/json")
	   public List<Test> getTests()
	   {
		   return testService.getTests();
	   }

	   @PostMapping(value="/addTest",consumes="application/json")
	   public ResponseEntity<String> insertTest(@RequestBody()Test test)
	   {
		   try {
			   testService.insertTest(test);
			   return new ResponseEntity<String>("Test Added",HttpStatus.OK);
		   }
		   catch(Exception ex)
		   {
		   return new ResponseEntity<String>(ex.getMessage()+"Insertion Failed",HttpStatus.BAD_REQUEST);
	   }
	   }
	   /*
	   @PutMapping(value="/updateTest",consumes="application/json")
	   public String updateBook(@RequestBody()Test test)
	   {
		   String message=testService.updateTest(test);
		   return message;
	   }
	   */
	   @DeleteMapping("/deleteTest/{testId}")
	   public ResponseEntity<String> deleteTest(@PathVariable int testId)
	   {
		   try {
			    testService.deleteTest(testId); 
			    return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
	    	  }
	    	  catch(Exception ex)
	    	  {
	    		  return new ResponseEntity<String>("Deletion Failed",HttpStatus.BAD_REQUEST);
	    	  }
	}
	}
	