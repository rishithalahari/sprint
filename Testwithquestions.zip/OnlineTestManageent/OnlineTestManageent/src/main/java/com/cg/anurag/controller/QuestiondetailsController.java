package com.cg.anurag.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.anurag.dto.Questiondetails;
import com.cg.anurag.dto.Test;
import com.cg.anurag.service.QuestiondetailsService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class QuestiondetailsController
{
	@Autowired
	QuestiondetailsService questionDetailsService;
	public void setDiagnosticcenterService(QuestiondetailsService questionDetailsService)
	{
		this.questionDetailsService=questionDetailsService;
	}
	@PostMapping(value="/addQuestionDetails/{testid}",consumes="application/json")
	   public ResponseEntity<String> insertQuestionDetails(@RequestBody()Questiondetails questionDetails)
	   {
		   String message="QuestionDetails Inserted Successfully";
		   if(questionDetailsService.insertQuestionDetails(questionDetails)==null)
			   message="QuestionDetails Insertion Failed";
		   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	   }
	@GetMapping("/getQuestionDetails/{testid}")
	   public List<Questiondetails> getQuestionDetails()
	   {
		   return questionDetailsService.getQuestionDetails();
	   }

}
