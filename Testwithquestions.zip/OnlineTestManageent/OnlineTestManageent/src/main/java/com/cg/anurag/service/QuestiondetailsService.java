package com.cg.anurag.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.cg.anurag.dao.QuestiondetailsDAO;
import com.cg.anurag.dto.Questiondetails;


@Service
public class QuestiondetailsService  {
	@Autowired
	QuestiondetailsDAO qdao;
    public void setAdao(   QuestiondetailsDAO qdao) 
    { 
    	this.qdao=qdao;
    	} 
    @Transactional
    public Questiondetails insertQuestionDetails(Questiondetails questionDetails)
    {
        return qdao.save(questionDetails);
    }
    
    @Transactional(readOnly = true)
    public Questiondetails getQuestionDetailsByTestId(int test_id)
    {
    	return qdao.getQuestionDetailsByTestId(test_id);
    }
    @Transactional(readOnly=true)
    public List<Questiondetails> getQuestionDetails()
    {
    	return qdao.findAll();
    }
 }
