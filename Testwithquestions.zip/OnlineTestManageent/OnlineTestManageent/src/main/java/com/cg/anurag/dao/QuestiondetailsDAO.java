package com.cg.anurag.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.cg.anurag.dto.Questiondetails;
@Repository
public interface QuestiondetailsDAO extends JpaRepository<Questiondetails,Integer>
{
	public Questiondetails getQuestionDetailsByTestId(int test_id);
	}

